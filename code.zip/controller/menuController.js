const Helper = require('../utils/helper');
const menuModel = require('../model/menuModel');
const { getCache, setCache, deleteByPattern } = require('../middleware/redis');

const addItem = async (req, res) => {
    try {
        const { name, description, category, price, isAvailable } = req.body;

        if (!name || !category || price === undefined) {
            return Helper.Fail(res, 'name, category, and price are required');
        }

        if (typeof price !== 'number' || price < 0) {
            return Helper.Fail(res, 'price must be a positive number');
        }

        const menu = await menuModel.create({
            name: name.trim(),
            description: description ? description.trim() : '',
            category: category.trim(),
            price,
            isAvailable: isAvailable !== undefined ? isAvailable : true,
            owner: req.user.userId
        });

        await deleteByPattern('menu:*');

        return Helper.Success(res, 'Menu created successfully', menu);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const updateItem = async (req, res) => {
    try {
        const id = req.params.id;
        if (!id) return Helper.Fail(res, 'menuId is required');

        const { name, description, category, price, isAvailable } = req.body;
        const obj = {};
        if (name) obj.name = name.trim();
        if (description !== undefined) obj.description = description.trim();
        if (category) obj.category = category.trim();
        if (price !== undefined) {
            if (typeof price !== 'number' || price < 0) {
                return Helper.Fail(res, 'price must be a positive number');
            }
            obj.price = price;
        }
        if (isAvailable !== undefined) obj.isAvailable = isAvailable;

        const menu = await menuModel.findByIdAndUpdate(id, obj, { new: true });
        if (!menu) return Helper.Fail(res, 'Menu item not found');

        await deleteByPattern('menu:*');

        return Helper.Success(res, 'Menu updated', menu);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const viewItem = async (req, res) => {
    try {
        const id = req.params.id;
        if (!id) return Helper.Fail(res, 'menuId is required');

        const menu = await menuModel.findById(id);
        if (!menu) return Helper.Fail(res, 'Menu item not found');

        return Helper.Success(res, 'Success', menu);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const listItems = async (req, res) => {
    try {
        const category = req.query.category ? req.query.category.trim() : '';
        const page = parseInt(req.query.page, 10) || 1;
        const limit = parseInt(req.query.limit, 10) || 10;
        const skip = (page - 1) * limit;

        const cacheKey = `menu:${category || 'all'}:${page}:${limit}`;
        const cachedResult = await getCache(cacheKey);
        if (cachedResult) {
            return Helper.Success(res, 'Success', cachedResult);
        }

        const filter = { isAvailable: true };
        if (category) {
            filter.category = { $regex: category, $options: 'i' };
        }

        const [list, total] = await Promise.all([
            menuModel.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
            menuModel.countDocuments(filter)
        ]);

        const result = {
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
            list
        };

        await setCache(cacheKey, result, 120);
        return Helper.Success(res, 'Success', result);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const getMyMenu = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1;
        const limit = parseInt(req.query.limit, 10) || 10;
        const skip = (page - 1) * limit;

        const [menus, total] = await Promise.all([
            menuModel.find({ owner: req.user.userId }).sort({ createdAt: -1 }).skip(skip).limit(limit),
            menuModel.countDocuments({ owner: req.user.userId })
        ]);

        return Helper.Success(res, 'Your menu items', {
            menus,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
            total
        });
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

module.exports = {
    addItem,
    updateItem,
    viewItem,
    listItems,
    getMyMenu
};
