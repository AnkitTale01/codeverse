const { createClient } = require('redis');
const dotenv = require('dotenv');

dotenv.config();

const REDIS_URL = process.env.REDIS_URL || 'redis://127.0.0.1:6379';
const redisClient = createClient({ url: REDIS_URL });
let redisAvailable = false;

redisClient.on('error', (err) => {
    console.error('Redis Client Error', err);
    redisAvailable = false;
});

const connectRedis = async () => {
    if (redisClient.isOpen) {
        redisAvailable = true;
        return;
    }

    try {
        await redisClient.connect();
        redisAvailable = true;
        console.log('Redis connected successfully');
    } catch (err) {
        redisAvailable = false;
        console.warn('Redis not available. Caching disabled.', err.message || err);
    }
};

const getCache = async (key) => {
    if (!redisAvailable) return null;
    try {
        const data = await redisClient.get(key);
        return data ? JSON.parse(data) : null;
    } catch (err) {
        console.warn('Redis get failed, falling back:', err.message || err);
        return null;
    }
};

const setCache = async (key, value, ttl = 60) => {
    if (!redisAvailable) return;
    try {
        await redisClient.set(key, JSON.stringify(value), {
            EX: ttl
        });
    } catch (err) {
        console.warn('Redis set failed, cache skipped:', err.message || err);
    }
};

const deleteByPattern = async (pattern) => {
    if (!redisAvailable) return;
    try {
        for await (const key of redisClient.scanIterator({ MATCH: pattern })) {
            await redisClient.del(key);
        }
    } catch (err) {
        console.warn('Redis delete pattern failed:', err.message || err);
    }
};

module.exports = {
    redisClient,
    connectRedis,
    getCache,
    setCache,
    deleteByPattern
};
