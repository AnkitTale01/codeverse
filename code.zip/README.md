Food Ordering Backend
A clean modular Express backend with MongoDB, Redis caching, JWT auth, and Socket.IO order notifications.

