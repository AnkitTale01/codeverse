const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    throw new Error('JWT_SECRET is required in environment configuration.');
}

const verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ status: 0, message: 'Authorization header missing', data: null });
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
        return res.status(401).json({ status: 0, message: 'Token missing', data: null });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        return next();
    } catch (error) {
        console.error(error);
        return res.status(403).json({ status: 0, message: 'Invalid or expired token', data: null });
    }
};

const sign = ({ userId, role }) => {
    if (!userId || !role) return false;
    return jwt.sign({ userId, role }, JWT_SECRET, { expiresIn: '7d' });
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({ status: 0, message: 'Access denied', data: null });
        }
        return next();
    };
};

module.exports = {
    verifyToken,
    sign,
    authorize
};
