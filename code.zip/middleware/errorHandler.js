const errorHandler = (err, req, res, next) => {
    console.error(err.stack || err);
    const status = err.status || 500;
    const message = err.message || 'Internal server error';
    res.status(status).json({ status: 0, message, data: null });
};

module.exports = errorHandler;
