const Helper = require('../utils/helper');
const Auth = require('../middleware/auth');
const userModel = require('../model/userModel');

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const registration = async (req, res) => {
    try {
        const { name, password, email, role } = req.body;

        if (!name || !email || !password || !role) {
            return Helper.Fail(res, 'name, email, password, and role are required');
        }

        if (!emailRegex.test(email)) {
            return Helper.Fail(res, 'Invalid email format');
        }

        if (!['user', 'owner'].includes(role)) {
            return Helper.Fail(res, 'role must be either user or owner');
        }

        const existingUser = await userModel.findOne({ email: email.toLowerCase().trim() });
        if (existingUser) {
            return Helper.Fail(res, 'Email already registered');
        }

        const hashedPassword = await Helper.hashPassword(password);
        const user = await userModel.create({
            name: name.trim(),
            email: email.toLowerCase().trim(),
            password: hashedPassword,
            role
        });

        const payload = { userId: user._id, role: user.role };
        const token = Auth.sign(payload);
        const result = user.toObject();
        result.token = token;
        delete result.password;

        return Helper.Success(res, 'User created successfully', result);
    } catch (error) {
        console.error(error);
        if (error.code === 11000) {
            return Helper.Fail(res, 'Email already registered');
        }
        return Helper.Fail(res, 'server error');
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return Helper.Fail(res, 'email and password are required');
        }

        const user = await userModel.findOne({ email: email.toLowerCase().trim() });
        if (!user) {
            return Helper.Fail(res, 'Invalid email or password');
        }

        const match = await Helper.verifyPassword(password, user.password);
        if (!match) {
            return Helper.Fail(res, 'Invalid email or password');
        }

        const token = Auth.sign({ userId: user._id, role: user.role });
        const result = user.toObject();
        result.token = token;
        delete result.password;

        return Helper.Success(res, 'Login successful', result);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

module.exports = {
    registration,
    login
};
