require('dotenv').config()

const mongoose = require("mongoose")
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URL, {

        });
        console.log('MongoDB Connected successfully!');
    } catch (error) {
        console.error(error.message);
        process.exit(1); // Exit process with failure
    }
};

module.exports = { connectDB }