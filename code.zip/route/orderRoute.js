const express = require('express')
const router = express.Router()
const Auth = require('../middleware/auth')
const orderController = require('../controller/orderController')

// Customer only
router.post('/', Auth.verifyToken, Auth.authorize('user'), orderController.createOrder);
router.get('/me', Auth.verifyToken, Auth.authorize('user'), orderController.getMyOrders);

// Owner only
router.get('/restaurant', Auth.verifyToken, Auth.authorize('owner'), orderController.getRestaurantOrders);
router.patch('/:id/accept', Auth.verifyToken, Auth.authorize('owner'), orderController.acceptOrder);
router.patch('/:id/cancel', Auth.verifyToken, Auth.authorize('owner'), orderController.cancelOrder);

module.exports = router
