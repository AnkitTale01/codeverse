const mongoose = require("mongoose")
const { Schema } = mongoose;

const menuSchema = new mongoose.Schema({
    category: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    description: {
        type: String
    },
    price: {
        type: Number,
        required: true
    },
    isAvailable: {
        type: Boolean,
        default: true
    },
    owner: {
        type: Schema.Types.ObjectId,
        ref: 'user',
        required: true
    }

}, {
    timestamps: true
})

const menu = mongoose.model('menu', menuSchema);
module.exports = menu;

