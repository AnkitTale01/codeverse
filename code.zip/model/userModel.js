const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        lowercase: true,
        trim: true
    },
    password: {
        type: String,
        required: true
    },
    role: {
        type: String,
        enum: ['user', 'owner'],
        default: 'user'
    }
}, {
    timestamps: true
});

userSchema.index({ email: 1 }, { unique: true });

const User = mongoose.model('user', userSchema);
module.exports = User;

