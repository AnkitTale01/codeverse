const express = require("express")
const router = express.Router()
const Auth = require("../middleware/auth")
const menuController = require("../controller/menuController")

router.get('/', menuController.listItems); // public
router.post('/', Auth.verifyToken, Auth.authorize('owner'), menuController.addItem);
router.patch('/:id', Auth.verifyToken, Auth.authorize('owner'), menuController.updateItem);
router.get('/me', Auth.verifyToken, Auth.authorize('owner'), menuController.getMyMenu);
router.get('/:id', Auth.verifyToken, Auth.authorize('owner'), menuController.viewItem);

module.exports = router
