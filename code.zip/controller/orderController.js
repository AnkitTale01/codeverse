const Helper = require('../utils/helper');
const menuModel = require('../model/menuModel');
const orderModel = require('../model/orderModel');

const createOrder = async (req, res) => {
    try {
        const { items, address } = req.body;

        if (!Array.isArray(items) || items.length === 0) {
            return Helper.Fail(res, 'items must be a non-empty array');
        }
        if (!address || typeof address !== 'string' || !address.trim()) {
            return Helper.Fail(res, 'address is required');
        }

        const menuIds = items.map((item) => item.menuItem);
        if (menuIds.some((id) => !id)) {
            return Helper.Fail(res, 'Each order item must include a menuItem id');
        }

        const menuItems = await menuModel.find({ _id: { $in: menuIds }, isAvailable: true });
        if (menuItems.length !== items.length) {
            return Helper.Fail(res, 'One or more menu items do not exist or are unavailable');
        }

        const restaurantId = menuItems[0].owner;
        for (const menu of menuItems) {
            if (menu.owner.toString() !== restaurantId.toString()) {
                return Helper.Fail(res, 'All items must be from the same restaurant');
            }
        }

        let totalPrice = 0;
        const orderItems = items.map((item) => {
            if (!item.quantity || typeof item.quantity !== 'number' || item.quantity < 1) {
                throw new Error('Each item must include a valid quantity');
            }
            if (item.price === undefined || typeof item.price !== 'number' || item.price < 0) {
                throw new Error('Each item must include a valid price');
            }
            const lineTotal = item.price * item.quantity;
            totalPrice += lineTotal;
            return {
                menuItem: item.menuItem,
                name: item.name || '',
                price: item.price,
                quantity: item.quantity
            };
        });

        const order = await orderModel.create({
            userId: req.user.userId,
            items: orderItems,
            totalPrice,
            restaurantId,
            address: address.trim(),
            status: 'Created'
        });

        const io = req.app.get('io');
        if (io && restaurantId) {
            io.to(restaurantId.toString()).emit('newOrder', order);
        }

        return Helper.Success(res, 'Order created', order);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, error.message === 'Each item must include a valid quantity' || error.message === 'Each item must include a valid price' ? error.message : 'server error');
    }
};

const getMyOrders = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1;
        const limit = parseInt(req.query.limit, 10) || 10;
        const skip = (page - 1) * limit;

        const [orders, total] = await Promise.all([
            orderModel.find({ userId: req.user.userId })
                .populate({ path: 'items.menuItem', select: 'name price category' })
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit),
            orderModel.countDocuments({ userId: req.user.userId })
        ]);

        return Helper.Success(res, 'Your orders', {
            orders,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
            total
        });
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const getRestaurantOrders = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1;
        const limit = parseInt(req.query.limit, 10) || 10;
        const skip = (page - 1) * limit;

        const [orders, total] = await Promise.all([
            orderModel.find({ restaurantId: req.user.userId })
                .populate({ path: 'items.menuItem', select: 'name price category' })
                .populate('userId', 'name email')
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit),
            orderModel.countDocuments({ restaurantId: req.user.userId })
        ]);

        return Helper.Success(res, 'Restaurant orders', {
            orders,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
            total
        });
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const acceptOrder = async (req, res) => {
    try {
        const order = await orderModel.findById(req.params.id).populate('items.menuItem');
        if (!order) return Helper.Fail(res, 'Order not found');
        if (order.restaurantId.toString() !== req.user.userId.toString()) return Helper.Fail(res, 'Not your order');
        if (order.status !== 'Created') return Helper.Fail(res, 'Cannot accept this order');

        order.status = 'Accepted';
        await order.save();

        const io = req.app.get('io');
        if (io) {
            io.to(order.restaurantId.toString()).emit('orderUpdate', order);
            io.to(order.userId.toString()).emit('orderUpdate', order);
        }

        return Helper.Success(res, 'Order accepted', order);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

const cancelOrder = async (req, res) => {
    try {
        const order = await orderModel.findById(req.params.id).populate('items.menuItem');
        if (!order) return Helper.Fail(res, 'Order not found');
        if (order.restaurantId.toString() !== req.user.userId.toString()) return Helper.Fail(res, 'Not your order');
        if (['Delivered', 'Cancelled'].includes(order.status)) return Helper.Fail(res, 'Cannot cancel this order');

        order.status = 'Cancelled';
        await order.save();

        const io = req.app.get('io');
        if (io) {
            io.to(order.restaurantId.toString()).emit('orderUpdate', order);
            io.to(order.userId.toString()).emit('orderUpdate', order);
        }

        return Helper.Success(res, 'Order cancelled', order);
    } catch (error) {
        console.error(error);
        return Helper.Fail(res, 'server error');
    }
};

module.exports = {
    createOrder,
    getMyOrders,
    getRestaurantOrders,
    acceptOrder,
    cancelOrder
};
