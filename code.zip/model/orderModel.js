const mongoose = require('mongoose');
const { Schema } = mongoose;

const orderItemSchema = new mongoose.Schema({
    menuItem: {
        type: Schema.Types.ObjectId,
        ref: 'menu',
        required: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: Number,
        required: true,
        min: 0
    },
    quantity: {
        type: Number,
        required: true,
        min: 1
    }
}, {
    _id: false
});

const orderSchema = new mongoose.Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'user',
        required: true
    },
    items: {
        type: [orderItemSchema],
        required: true,
        validate: {
            validator: (value) => Array.isArray(value) && value.length > 0,
            message: 'Order items must be an array with at least one element.'
        }
    },
    totalPrice: {
        type: Number,
        required: true,
        min: 0
    },
    status: {
        type: String,
        enum: ['Created', 'Accepted', 'Delivered', 'Cancelled'],
        default: 'Created'
    },
    restaurantId: {
        type: Schema.Types.ObjectId,
        ref: 'user',
        required: true
    },
    address: {
        type: String,
        trim: true,
        required: true
    }
}, {
    timestamps: true
});

orderSchema.index({ userId: 1 });
orderSchema.index({ restaurantId: 1 });

const order = mongoose.model('order', orderSchema);
module.exports = order;

