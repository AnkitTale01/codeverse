require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const http = require('http');
const { Server } = require('socket.io');

const { connectDB } = require('./middleware/db');
const { connectRedis } = require('./middleware/redis');
const errorHandler = require('./middleware/errorHandler');
const menuRoute = require('./route/menuRoute');
const userRoute = require('./route/userRoute');
const orderRoute = require('./route/orderRoute');

const app = express();
app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.json({ status: 1, message: 'API is running' });
});

app.use('/auth', userRoute);
app.use('/menu', menuRoute);
app.use('/orders', orderRoute);

const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: true,
        methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE']
    }
});
app.set('io', io);

io.on('connection', (socket) => {
    console.log('user connected', socket.id);

    socket.on('joinOwnerRoom', (ownerId) => {
        if (ownerId) {
            socket.join(ownerId);
            console.log('owner joined room', ownerId);
        }
    });

    socket.on('joinCustomerRoom', (userId) => {
        if (userId) {
            socket.join(userId);
            console.log('customer joined room', userId);
        }
    });

    socket.on('disconnect', () => {
        console.log('user disconnected', socket.id);
    });
});

app.use(errorHandler);

const PORT = process.env.PORT || 3000;

const startApp = async () => {
    await connectDB();
    await connectRedis();
    server.listen(PORT, () => {
        console.log(`Server listening on port ${PORT}`);
    });
};

startApp();
