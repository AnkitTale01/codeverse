const bcrypt = require('bcrypt');

function Success(res, message, data) {
    return res.status(200).json({ status: 1, message, data });
}

function Fail(res, message) {
    return res.status(400).json({ status: 0, message, data: null });
}

async function hashPassword(password) {
    const saltRounds = 10;
    const hash = await bcrypt.hash(password, saltRounds);
    return hash;
}

async function verifyPassword(password, hash) {
    const match = await bcrypt.compare(password, hash);
    return match; // returns a boolean (true or false)
}

module.exports = {
    Success,
    Fail,
    hashPassword,
    verifyPassword
}
